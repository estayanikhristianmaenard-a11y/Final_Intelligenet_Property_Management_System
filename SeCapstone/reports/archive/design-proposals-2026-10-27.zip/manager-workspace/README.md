# Manager workspace concept

Proposed visual direction, 23 October 2026. This is a static mockup for approval, not a screenshot of the running portal. All names, amounts and records are fictional.

- [PNG preview](manager-dashboard.png)
- [Editable SVG](manager-dashboard.svg)
- [Current implemented dashboard](../../mockups/01-manager-dashboard.png)

The concept keeps the selected integrated-R mark, muted blue navigation, pale blue-gray top bar and existing Manager destinations. It uses one clear decision list, quiet totals and property rows instead of repeated nested cards. Recent activity stays secondary. Proposal/rent/case links represent existing review pages; they do not imply new approval or payment behavior.

The sidebar is shown expanded to make labels easy to assess. Existing desktop hover expansion, sidebar scrolling, logout position and mobile navigation preferences remain requirements for any later implementation. This desktop concept does not change those behaviors.

No application source, database, integration setting or existing screenshot was changed. UI implementation requires the user's approval of this direction. The PNG is static and cannot demonstrate animation, responsiveness or accessibility behavior.

If approved, apply the hierarchy and spacing to the Manager dashboard first, then review actual responsive pages before extending the treatment to Staff, Tenant and Admin. Keep keyboard focus, existing actions/permissions, reduced-motion support and current font assets. Prefer subtle color/opacity transitions rather than moving cards or additional animation dependencies.

Regenerate only this concept from its folder with `node render-preview.mjs`. It uses the portal's installed Playwright and local Edge, opens the SVG from disk and makes no network requests.
