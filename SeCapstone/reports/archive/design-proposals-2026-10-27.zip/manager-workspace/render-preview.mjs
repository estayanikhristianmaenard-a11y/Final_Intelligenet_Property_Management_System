// Local vector-to-PNG export for this approval mockup only.
import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { fileURLToPath } from "node:url";
const require = createRequire(new URL("../../../rentara-portal/package.json", import.meta.url));
const { chromium } = require("@playwright/test");
const browser = await chromium.launch({headless:true,...(process.platform === "win32" ? {executablePath:process.env.BROWSER_EXECUTABLE || "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe"} : {})});
try {
  const page = await browser.newPage({viewport:{width:1600,height:1080},deviceScaleFactor:1,reducedMotion:"reduce"});
  const errors = [];
  page.on("pageerror",error=>errors.push(error.message));
  await page.route(/^https?:/,route=>route.abort());
  await page.goto(new URL("manager-dashboard.svg",import.meta.url).href);
  await page.evaluate(()=>document.fonts.ready);
  const audit = await page.evaluate(()=>{
    const svg=document.documentElement;
    const bounds=svg.viewBox.baseVal;
    const outside=[...document.querySelectorAll("text")].filter(el=>{
      const b=el.getBBox();return b.x<0 || b.y<0 || b.x+b.width>bounds.width+1 || b.y+b.height>bounds.height+1;
    }).map(el=>el.textContent);
    return {width:bounds.width,height:bounds.height,texts:document.querySelectorAll("text").length,outside,parserErrors:document.querySelectorAll("parsererror").length};
  });
  assert.equal(audit.width,1600);assert.equal(audit.height,1080);
  assert.equal(audit.parserErrors,0);assert.deepEqual(audit.outside,[]);assert.deepEqual(errors,[]);
  const output=fileURLToPath(new URL("manager-dashboard.png",import.meta.url));
  await page.screenshot({path:output,fullPage:false,animations:"disabled"});
  console.log(JSON.stringify({output,width:audit.width,height:audit.height,textElements:audit.texts,externalRequests:"blocked",bounds:"passed"}));
} finally {await browser.close();}
