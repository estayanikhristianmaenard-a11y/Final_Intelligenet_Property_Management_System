# Claude case-sheet review — 27 October 2026

The attached SVG was preserved unchanged as `claude-case-sheet.svg` and rendered locally as `claude-case-sheet.png`. It contains internal SVG symbol references only; external HTTP requests were blocked during rendering. SVG parsing and whole-artboard text bounds passed. Visual inspection still found internal layout defects, demonstrating why those checks alone do not establish a correct layout. No portal code, data or approved workflow was changed for this review.

## Design assessment

The case sheet is a useful direction for the shared Bills & Payments review page. Its strengths are one selected case, field-focused attention, a visible evidence area and a final action block that differs by role. It is not yet a redesign of the landing dashboard, property pages, account maintenance or the rest of the application. Preserve one shared shell and review component; do not make independent Staff/Manager application copies.

The rendered SVG highlights the Provider row even though Due date is the unreadable field. In the Manager queue, the shared selected-case text and the added proposal subtitle overlap. The selected-case queue also says “Due 28 Oct” without indicating that this date is proposed or source-observed rather than validated. Use “Date needs review,” or explicitly identify a proposed date. Small labels and action targets need enlargement when preparing an implementation; the SVG is not a tested phone interface.

“Matches” is stronger than the current evidence. An extracted amount with a valid numeric format is not automatically proven equal to the original bill. Use “Extracted,” “Mapped” or the applicable validation result. Reserve “Checked against original” for an actual human check if that action and its attribution are implemented. Highlight only the failed field and retain access to the actual original.

The supplied excerpt is re-typeset illustrative text, not a crop of a real source image. The current saved intake document retains raw text, confidence, source-file references and extracted fields; it does not retain OCR bounding boxes for automatic image crops. An OCR text excerpt is not independent evidence that the same OCR read a field correctly. Keep the existing original PDF/image preview, with user-controlled zoom if needed, rather than introducing an automatic cropping subsystem. A manually selected crop or native PDF text excerpt is a different proposal and should not be represented as an existing automatic feature.

## Answers and corrections to send back

Only the Manager creates or changes a verified utility-account mapping. Staff may investigate and propose an extracted account-reference correction from a readable original, with a required reason. Manager authorization then revalidates against the registered mappings. Staff cannot link an account to a unit directly, and neither role should guess hidden characters in a masked identifier.

There are not five separately persisted lifecycle states for Received, Read, Validated, Classified and Allocated. Incoming documents use `ocrStatus` values including `processing`, `failed` and `validated`, together with `processingOutcome`, source timestamps, related bills and rule-level `validationResults` (`passed`, `failed`, `not_run`). Some classification checks can be evaluated in the same processing attempt that fails another validation rule; a rigid sequential five-step trail can misrepresent that behavior. Prefer a compact existing-state summary such as Processing, Needs review or Processed. Do not introduce extra stored lifecycle states solely to support a decorative trail. A validation timestamp alone does not establish successful validation.

Proposal states are `pending`, `applied`, `rejected`, `returned` and `stale`. A deliberate Manager rejection requires a reason and creates `rejected`. An authorization attempt that fails validation rolls back the proposed billing change and creates `returned`. A changed source, billing context or preparer access can create `stale`. The Returned UI queue can group these latest outcomes where the case is Staff-owned, but they must remain distinct in history and displayed reasons.

Staff submission already requires a written correction reason of 3–1000 characters on the server. The existing form labels this as reason and source evidence. This requirement does not automatically verify the evidence or require an attached crop. Manager direct correction is already implemented and should remain available as a secondary permitted action; D should not remove it.

Unfinalized incoming sources are separate from published Tenant bills. Failed validation creates or retains exceptions and stops before charge allocation/publication. Successful processing creates the assigned Tenant bills. A new Tenant-side “validated” flag is not required merely to hide a held incoming source. Existing finalized bills affected by a later unsuccessful correction must also not be indiscriminately hidden.

The current A/B/C boards label the Tenant view “after validation,” and their README explicitly separates workflow stages. Showing the same fictional water bill later in the Tenant view was therefore not intended as simultaneous exposure of an unvalidated bill. Claude's concern is useful for presentation clarity: D's omission of the held bill makes the example easier to understand, but this is not evidence that the current backend publishes held sources.

## Suggested next revision

Keep D as a proposal for the shared bill-review component. Correct the highlight, overlapping queue text, ambiguous due date and evidence labels; derive the status summary from existing stored outcomes; keep an original-source preview; retain Manager direct correction. Keep Tenant personal utility marks separate from provider verification, with one nearby disclaimer and an accessible month calendar. Keep Admin maintenance separate from operational financial authority. No new module or workflow state is necessary for this direction.

## Source locations checked

`server/service.js`: `writeEntity`, `processIncoming`, charge publication and direct corrections. `server/staff-workflow.js`: `submitProposal`, `decideProposal`, reason validation and state transitions. `server/integrations.js`: retained intake/extraction fields. `src/features/billing/work-queue.js`: UI grouping. `src/app/workflows.js`: Staff proposal routing and Manager source correction. `src/features/billing/correction-proposals.js`: existing correction form and proposal controls. These checks describe current source behavior, not a fresh live-device acceptance run.


## Revised attachment ? second visual check, 27 October 2026

The second supplied SVG is preserved unchanged as claude-case-sheet-v2.svg and rendered as claude-case-sheet-v2.png. Parsing and outer-artboard bounds passed; the revised image was visually inspected. The original five issues are substantially addressed: the Due date row is highlighted, Manager queue subtitles no longer overlap, Extracted replaces Matches, the invented source excerpt is removed, and a source-state summary replaces the unsupported five-step trail. Earlier findings above describe the first attachment and must not be treated as unchanged v2 defects.

One previous ambiguity remains: the shared selected queue row still says Due 28 Oct while the extracted due date is unavailable. Staff should see Date needs review (or no due date), and Manager may see Proposed: 28 Oct if tied to the proposal, rather than a finalized due date. Manager direct correction is still not pictured; preserve it as a secondary Manager-only action. Final implementation should enlarge small labels/controls, provide persistent field labels for correction and reason, and retain full month-calendar access and category icons on phones.

Current intake presentation maps validated sources to Processed, failed sources to Needs review, V04 duplicate failures to Duplicate and other in-progress sources to Processing. Proposal labels remain separate: pending maps to With Manager, applied to Applied, rejected to Rejected, returned to Returned and stale to Needs recheck. Show the actual retained reason. A source can remain failed while a proposal is pending; do not collapse the source outcome and proposal decision into one backend state.

Open original is already supported through the existing authenticated preview. GET /api/v1/incoming/:id/source is limited to Staff/Manager in the authorized workspace and reads the retained source file. src/components/source-preview.js fetches it with the session token, then displays PDFs or images via a temporary blob URL. It revokes that URL on close. Reuse that component; do not make the API resource a public link or assume a bare anchor will supply authentication. Non-previewable or unavailable originals need the existing download/text/error fallback. This was a code and SVG review, not a new live integration or device test. No portal behavior was changed.


## Third attachment ? queue semantics confirmed, 27 October 2026

Preserved the supplied third SVG as claude-case-sheet-v3.svg and rendered claude-case-sheet-v3.png. Parsing and whole-artboard text bounds passed, and the image was visually inspected. The ambiguous queue date is now replaced with Date needs review for Staff and Proposed: 28 Oct for Manager. Manager direct correction is restored as a secondary link; Staff does not have it. No obvious text collisions remain in the rendered board, although final implementation still needs readable labels, persistent input labels, 44px targets and responsive checks.

A source outcome and an assignment queue are separate dimensions. A source may still need review while its pending proposal is With Manager. Existing staffQueues excludes pending-proposal/Manager-owned cases from Staff's actionable queue. After submission, Staff should see that source under With Manager with submission/history access rather than a second Submit action. The backend already rejects a second pending proposal for the same source. The board is coherent if the Staff view is the pre-submission stage and the Manager view is the later decision stage; label those stages explicitly if both examples show the same case.

Keep the current work-queue headings Needs action, With Manager, Returned and Resolved distinct from bill outcome Needs review and proposal outcome Rejected/Returned/Needs recheck. The earlier list of source/proposal labels was not a prohibition on useful responsibility headings such as With Staff or Your decisions. There is no need for a new stored status, duplicate case or workflow change to resolve the wording. The authenticated original preview remains supported. This version is a suitable visual basis for shared bill review, not an implementation or a full landing-dashboard design.
