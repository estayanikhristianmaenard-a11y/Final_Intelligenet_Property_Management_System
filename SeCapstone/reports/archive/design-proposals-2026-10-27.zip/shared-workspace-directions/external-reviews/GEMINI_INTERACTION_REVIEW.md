# Gemini interaction-state review ? 27 October 2026

Gemini's response uses an older Case Sheet screenshot. Use Claude's third attachment as the structural reference. The supplied SVG is preserved as gemini-interaction-states-original.svg. It contained unescaped ampersands and did not parse as XML. Twenty-one bare ampersands were escaped in the separate gemini-interaction-states-render.svg solely to render a preview. No workflow, content or layout corrections were made to that preview. The resulting PNG and outer-artboard check are saved beside these files. No portal code, database, credentials or integration was changed.

## Keep

Keep a single clear selected row, restrained hover color, visible keyboard focus and touch-sized controls. Preserve entered values after field validation or failed save; retain a required correction reason, clear saving feedback and duplicate-click protection. Use an accessible selected-date list for several actual bills on one date, category icons, and clearly labelled future rent dates. Keep one nearby personal-tracking disclaimer and a month view. Much of the existing form, action feedback, calendar and reduced-motion behavior already supports these needs; inspect and reuse it instead of adding duplicate implementations.

## Correct before implementation

Returned is not a Manager action for asking for better evidence. The backend sets returned when attempted authorization fails validation and rolls back the billing change. A deliberate Manager rejection with a reason creates rejected. Needs recheck represents a stale proposal after source, billing context or preparer access changes; it does not mean authorization is presently running. Pending proposals are With Manager. An incoming source outcome and proposal state remain separate dimensions.

Do not add the drawn Return to Staff button merely to match this SVG. Retain Authorize, Reject with reason, and the existing secondary Manager direct-correction path. Rejecting a proposal does not reject, close or delete its source document. A duplicate intake result is a Duplicate source outcome, not a Rejected proposal.

Remove the obsolete five-node pipeline, automatically matching field claims, highlighted Provider row, retyped original excerpt and unvalidated Due 28 Oct label. These were corrected in Claude v3 already. Open the authenticated retained original rather than presenting OCR text as independent evidence. Display actual stored failure/decision reasons.

The calendar puts 30 November 2026, a Monday, in the Sunday column of the October 26?November 1 week. Render a real week/month grid or use a chronological agenda; put the later November rent estimate in a separately labelled row or the correct month view. The illustration also changes the selected water bill from October 28 to October 27 to create a shared date. Use consistent declared fictional records or separate validated examples rather than altering actual bill dates to fit a demonstration. The current calendar model previews a future rent date without estimating an amount; the proposed estimated PHP 6,000 amount is additional behavior, not an existing date-only presentation rule.

A selected-date detail list needs JavaScript state, keyboard interaction and appropriate semantics, not CSS alone. Preserving form values is client behavior, already partly covered by existing tests; Rentara is not a server-rendered req.body template application. Manager direct correction is an existing permission and endpoint, but a new inline editor must retain current reason, validation, history and stale-proposal safeguards. Permission checks cannot be reduced to a client-side role toggle.

Do not guarantee zero data loss. Existing preservation covers tested form-error scenarios, not browser closure, reload, device loss or all network failures. After an uncertain save response, existing server-side pending-proposal/duplicate checks still matter; do not blindly treat a retry as proof that the first request never saved. Success messages must follow the real returned result, not a timer or an optimistic label.

## Simplify the visual specification

The single phone board repeats the same bills in the tracker, calendar detail and agenda, with multiple nested boxes and disclaimers. Prefer the tracker plus one selected-date detail area, retaining access to the existing full month. A skeleton indicates that data is loading; it must not claim email OCR is actively running unless the server outcome establishes that. An empty personal queue should say there is no work in that queue rather than asserting that every exception in the system is resolved.

Keep the project's existing restrained transition timing and slow desktop sidebar behavior. Do not enforce Gemini's universal 150ms timing or remove sidebar expansion. Approximately 260?360ms color/opacity feedback is consistent with current tokens for ordinary interactions; reduced-motion preference should remove optional animation. An SVG cannot demonstrate smoothness, device accessibility or performance. Enlarge small labels and check text within each nested phone/panel; whole-artboard bounds do not detect internal overflow or crowded content.

## Existing source basis

src/components/action-feedback.js already provides request-linked loading and duplicate-click protection. src/app/workflows.js retains form contents and displays errors when save fails. src/features/billing/work-queue.js separates bill outcomes and responsibility groups. server/staff-workflow.js defines proposal outcomes, reason requirements and atomic revalidation. src/features/tenant/calendar-model.js generates date-only future rent estimates without utility predictions. The earlier source checks and browser regression evidence remain dated evidence; this review did not rerun live integrations or physical-device tests.

Recommendation: retain Claude v3 as the case-sheet foundation. Borrow Gemini's interaction presentation only after these semantic corrections. No extra business module or new lifecycle state is needed.
