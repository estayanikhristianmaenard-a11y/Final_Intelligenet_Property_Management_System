"""Offline SVG proposals. Does not import the portal or read its data/configuration."""
from pathlib import Path
from html import escape
import calendar
import json

ROOT = Path(__file__).resolve().parent
INK, MUTED, BLUE, NAVY = '#18344b', '#566f82', '#315ed1', '#173d59'
LINE, PALE, BG, AMBER = '#d7e2ec', '#e6eef6', '#f3f6f9', '#946113'
ICONS = {
 'home':'<path d="m3 10 9-7 9 7M5 9v12h14V9M9 21v-7h6v7"/>',
 'grid':'<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/>',
 'building':'<path d="M4 21V3h11v18M15 10h5v11M2 21h20M7 7h5M7 11h5M7 15h5"/>',
 'door':'<path d="M5 21V4l13-2v19M3 21h18M14 12h.1"/>',
 'people':'<circle cx="9" cy="8" r="3"/><path d="M3 21v-3a6 6 0 0 1 12 0v3M16 5a3 3 0 0 1 0 6M21 21v-3a6 6 0 0 0-4-5"/>',
 'bill':'<path d="M5 21V3h14v18l-3-2-4 2-4-2zM8 8h8M8 12h8M8 16h4"/>',
 'chart':'<path d="M3 3v18h18M7 16v-5M12 16V7M17 16v-7"/>',
 'settings':'<path d="M3 6h18M3 12h18M3 18h18"/><circle cx="8" cy="6" r="2"/><circle cx="16" cy="12" r="2"/>',
 'bell':'<path d="M5 17h14l-2-3V9a5 5 0 0 0-10 0v5zM10 21h4"/>',
 'bolt':'<path d="m13 2-8 12h6l-1 8 9-13h-7z"/>',
 'water':'<path d="M12 2C9 7 5 11 5 15a7 7 0 0 0 14 0c0-4-4-8-7-13z"/>',
 'search':'<circle cx="10" cy="10" r="6"/><path d="m15 15 6 6"/>',
 'menu':'<path d="M3 6h18M3 12h18M3 18h18"/>',
 'logout':'<path d="M9 4H4v16h5M10 12h11M17 8l4 4-4 4"/>',
}

class SVG:
 def __init__(self, title, w=1360, h=840):
  self.w,self.h=w,h
  self.p=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" role="img" aria-label="{escape(title)}"><title>{escape(title)}</title><desc>Visual proposal only. Fictional records, not implemented. One shared application; actions depend on role.</desc><g font-family="Segoe UI,Arial,sans-serif" style="font-variant-numeric:tabular-nums">']
 def rect(self,x,y,w,h,fill='white',r=0,stroke='none'):
  self.p.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}"/>')
 def text(self,x,y,value,size=15,color=INK,weight=400,anchor='start',serif=False):
  self.p.append(f'<text x="{x}" y="{y}" font-size="{size}" fill="{color}" font-weight="{weight}" text-anchor="{anchor}"'+(' font-family="Georgia,serif"' if serif else '')+f'>{escape(str(value))}</text>')
 def line(self,x,y,x2,y2,color=LINE,width=1):
  self.p.append(f'<path d="M{x} {y}H{x2}" fill="none" stroke="{color}" stroke-width="{width}"/>' if y==y2 else f'<path d="M{x} {y}L{x2} {y2}" fill="none" stroke="{color}" stroke-width="{width}"/>')
 def icon(self,name,x,y,color=MUTED,size=20):
  self.p.append(f'<svg x="{x}" y="{y}" width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" stroke="{color}" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">{ICONS[name]}</svg>')
 def logo(self,x,y,color='white',size=28):
  self.p.append(f'<svg x="{x}" y="{y}" width="{size}" height="{size}" viewBox="0 0 64 64"><path d="M17 53V23L32 11l16 12v9c0 7-5 11-12 11H20m13 0 15 10M19 28h15a7 7 0 0 1 0 14" fill="none" stroke="{color}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg>')
 def button(self,x,y,w,label,primary=True,h=42):
  self.rect(x,y,w,h,BLUE if primary else 'white',6,'none' if primary else LINE)
  self.text(x+w/2,y+h/2+5,label,14,'white' if primary else INK,600,'middle')
 def tag(self,x,y,label,color=AMBER,fill='#f6efdf',w=100):
  self.rect(x,y,w,26,fill,4);self.text(x+10,y+18,label,12,color,600)
 def date(self,x,y,day,month='OCT',dark=False):
  self.rect(x,y,48,58,BLUE if dark else PALE,5)
  self.text(x+24,y+18,month,10,'white' if dark else MUTED,600,'middle')
  self.text(x+24,y+44,day,25,'white' if dark else INK,600,'middle')
 def finish(self):return ''.join(self.p)+'</g></svg>'

def shell(s,role,active='Dashboard',navy=NAVY):
 s.rect(0,0,1360,840,BG);s.rect(0,0,204,840,navy)
 s.logo(22,22);s.text(58,45,'Rentara',23,'white',600)
 s.text(24,88,'Riverside management',12,'#c4d7e5')
 items=[('Dashboard','grid'),('Properties','building'),('Units','door'),('Tenants','people'),('Bills & Payments','bill')]
 items += [('Reports','chart'),('Settings','settings')] if role=='Manager' else [('Account','settings')]
 for i,(label,ico) in enumerate(items):
  y=126+i*55
  if label==active:
   s.rect(12,y-26,180,43,'#345d78',5)
   s.p.append(f'<path d="M12 {y-12}l6 7-6 7" fill="#d2e5f1"/>')
  s.icon(ico,24,y-16,'#d2e5f1',18);s.text(54,y,label,14,'white' if label==active else '#cedee9',600 if label==active else 400)
 s.icon('logout',24,743,'#cedee9',18);s.text(54,758,'Sign out',14,'#cedee9')
 s.line(20,784,184,784,'#45617a');s.text(24,810,'Alex Mendoza' if role=='Manager' else 'Lea Santos',13,'white',600)
 s.rect(204,0,1156,66,'#e5edf4');s.text(242,40,'Riverside management',14,MUTED)
 s.rect(965,15,306,36,'#f8fbfd',6);s.icon('search',979,24,size=17);s.text(1006,39,'Search records…',13,MUTED);s.icon('bell',1305,23,size=20)
 s.text(242,94,'Workspace / '+active,12,MUTED);s.text(1320,94,role,12,BLUE,600,'end')

def folio(role):
 s=SVG('A · Rental folio · '+role);shell(s,role)
 s.text(242,145,"Today's work",37,serif=True);s.text(1320,140,'Friday, 23 October 2026',13,MUTED,anchor='end')
 s.text(243,176,'Review Staff proposals and reported rent.' if role=='Manager' else 'Investigate bill exceptions and prepare corrections.',15,MUTED)
 tabs=['Your decisions  3','All cases','Recent activity'] if role=='Manager' else ['Needs action  3','With Manager  1','Returned  0']
 for x,t in zip([242,435,575],tabs):s.text(x,222,t,14,BLUE if x==242 else MUTED,600 if x==242 else 400)
 s.line(242,236,946,236);s.line(242,236,385,236,BLUE,2)
 s.text(242,266,'DUE',10,MUTED,600);s.text(316,266,'BILL / NEXT ACTION',10,MUTED,600)
 rows=[('28' if role=='Manager' else '—','Manila Water · Unit 1A','Correction prepared by Lea Santos' if role=='Manager' else 'Due date unreadable · compare the original','₱283.97','Review correction' if role=='Manager' else 'Investigate bill'),
       ('30' if role=='Manager' else '—','Rent report · Unit 2B' if role=='Manager' else 'Meralco · account needs linking','Juan Reyes · awaiting Manager confirmation' if role=='Manager' else 'Account incomplete · investigate the source','₱5,500.00' if role=='Manager' else '—','Review rent report' if role=='Manager' else 'Open case'),
       ('—','Utility account needs linking' if role=='Manager' else 'Manila Water · Unit 3C','Account incomplete · escalated by Staff' if role=='Manager' else 'Billing period missing · supported source needed','—','Review case' if role=='Manager' else 'Investigate bill')]
 for i,(day,title,detail,amount,action) in enumerate(rows):
  y=291+i*115;s.date(242,y,day,'OCT' if day!='—' else 'DATE')
  s.text(314,y+22,title,18,weight=600);s.text(314,y+49,detail,13,MUTED)
  if i==0:s.text(314,y+72,'Proposed due date' if role=='Manager' else 'Date requires review',12,AMBER)
  s.text(944,y+23,amount,17,weight=600,anchor='end');s.text(944,y+82,action+' ›',13,BLUE,600,'end')
  s.line(314,y+100,946,y+100)
 s.text(242,690,'Valid bills continue automatically.',14,MUTED)
 s.text(242,743,'Recently processed',14,weight=600);s.text(242,773,'Meralco · Unit 2B',14);s.text(946,773,'Bill available to the assigned Tenant',12,MUTED,anchor='end')
 s.line(982,210,982,786)
 s.text(1014,225,'Selected bill',14,MUTED);s.text(1014,263,'Manila Water',24,serif=True);s.text(1014,290,'Unit 1A · Maria Reyes',14,MUTED)
 s.text(1014,343,'₱283.97',35,weight=600);s.line(1014,367,1320,367)
 for y,label,val in [(402,'Account','TEST-WATER-001'),(447,'Billing period','23 Sep – 22 Oct 2026'),(492,'Extracted due date','Unreadable')]:
  s.text(1014,y,label,12,MUTED);s.text(1014,y+22,val,14,AMBER if y==492 else INK,600)
 s.rect(1004,546,326,102,PALE,6);s.text(1020,571,'Source evidence',12,MUTED);s.text(1020,598,'28 October 2026',19,weight=600)
 s.text(1020,626,'Live billing has not changed.',13,MUTED)
 s.button(1014,679,306,'Open correction' if role=='Manager' else 'Prepare correction')
 s.text(1014,755,'Riverside Apartments',14,weight=600);s.text(1014,781,'3 of 4 units occupied',13,MUTED)
 return s

def review_desk(role):
 s=SVG('B · Review desk · '+role);shell(s,role,'Bills & Payments','#24465f')
 s.text(242,142,'Bills & payments',31,weight=600);s.text(242,174,'Incoming bills    /    Exceptions    /    Billing history',14,MUTED)
 s.line(242,192,1320,192)
 s.text(242,230,'Your work',16,weight=600);s.text(412,230,'3 cases',12,MUTED,anchor='end')
 for y,title,detail,sel in [(267,'Manila Water','Unit 1A · due date',True),(371,'Meralco','Account needs linking',False),(475,'Manila Water','Unit 3C · billing period',False)]:
  if sel:s.rect(228,y-26,210,86,PALE,5);s.rect(228,y-26,3,86,BLUE)
  s.text(242,y,title,15,weight=600);s.text(242,y+26,detail,12,MUTED)
 s.text(242,650,'With Manager  1',13,MUTED);s.text(242,687,'Returned  0',13,MUTED)
 s.line(452,215,452,787);s.line(891,215,891,787)
 s.text(478,230,'Original bill',16,weight=600);s.text(858,230,'PDF · 1 page',12,MUTED,anchor='end')
 s.rect(474,253,390,486,'#e4ebf1',7);s.rect(492,271,354,449,'white')
 s.text(514,304,'MANILA WATER',19,weight=600);s.text(514,329,'Illustrative billing statement',12,MUTED)
 s.line(514,347,824,347);s.text(514,379,'Riverside Apartments · Unit 1A',14,weight=600)
 for y,label,val in [(415,'Contract account number','TEST-WATER-001'),(477,'Billing period','23 Sep to 22 Oct 2026'),(539,'Total amount due','PHP 283.97'),(601,'Due date','28 October 2026')]:
  s.text(514,y,label,12,MUTED);s.text(514,y+25,val,18 if y>=539 else 15,weight=600)
 s.rect(505,610,328,30,'none',3,BLUE)
 s.text(514,693,'FICTIONAL SOURCE · NO REAL ACCOUNT',10,MUTED)
 s.text(478,774,'Download original  ↓',13,BLUE,600)
 s.text(919,230,'What the system read',19,weight=600)
 for y,key,val in [(274,'Provider','Manila Water'),(327,'Account','TEST-WATER-001'),(380,'Amount due','₱283.97'),(433,'Due date','Unreadable')]:
  s.text(919,y,key,12,MUTED);s.text(1318,y+1,val,15,AMBER if y==433 else INK,600,'end');s.line(919,y+18,1320,y+18)
 s.tag(919,474,'Needs correction',w=135)
 s.text(919,539,'Proposed correction' if role=='Manager' else 'Prepare a correction',19,weight=600)
 s.text(919,571,'Due date',12,MUTED);s.rect(919,585,401,45,'white',5,LINE);s.text(933,614,'28 October 2026',16,weight=600)
 s.text(919,659,'Original bill clearly shows October 28.',13,MUTED)
 s.text(919,687,'Prepared by Lea Santos' if role=='Manager' else 'Add your source evidence before submitting.',12,MUTED)
 if role=='Manager':
  s.button(919,741,248,'Authorize correction');s.button(1179,741,141,'Reject',False)
 else:s.button(919,741,401,'Submit for Manager review')
 s.text(919,813,'Billing changes only after authorization and revalidation.',12,MUTED)
 return s

def register(role):
 s=SVG('C · Property register · '+role);shell(s,role,navy='#192f49')
 s.text(242,143,'Riverside Apartments',32,weight=600);s.text(242,176,'Pasig City · 3 of 4 units occupied',14,MUTED)
 s.button(1094,116,226,'Review decisions (2)' if role=='Manager' else 'Open daily work')
 for x,t in [(242,'Riverside Apartments'),(484,'Maple Court Homes')]:s.text(x,225,t,14,BLUE if x==242 else MUTED,600 if x==242 else 400)
 s.line(242,242,1320,242);s.line(242,242,430,242,BLUE,2)
 s.text(242,283,'Unit register',17,weight=600);s.text(948,283,'October 2026',13,MUTED,anchor='end')
 s.rect(242,302,712,36,'#e5edf4')
 for x,label in [(257,'UNIT'),(336,'TENANT'),(568,'MONTHLY RENT'),(731,'DUE'),(811,'RENT STATUS')]:s.text(x,326,label,10,MUTED,600)
 for i,(unit,name,rent,due,status) in enumerate([('1A','Maria Reyes','₱6,000.00','Oct 30','Unpaid'),('2B','Juan Reyes','₱5,500.00','Oct 30','Reported paid'),('3C','Ana Cruz','₱4,500.00','Oct 30','Paid'),('4D','Vacant','—','—','—')]):
  y=338+i*86
  if i==0:s.rect(242,y,712,86,'#e7eff8');s.rect(242,y,3,86,BLUE)
  col=MUTED if i==3 else INK
  s.text(258,y+33,unit,18,col,600);s.text(336,y+33,name,15,col,600 if i==0 else 400)
  if i==0:s.text(336,y+59,'Water bill needs review',12,AMBER)
  s.text(699,y+33,rent,14,col,600,'end');s.text(732,y+33,due,13,col)
  s.text(811,y+33,status,12,'#2c7157' if i==2 else AMBER if i==1 else col)
  s.line(242,y+85,954,y+85)
 s.text(242,731,'Recorded rent and occupancy',13,MUTED);s.text(242,762,'Open a unit to see its tenants, bills and linked accounts.',14,MUTED)
 s.line(985,271,985,790)
 s.text(1017,286,'Unit 1A',26,weight=600);s.text(1017,318,'Maria Reyes',17);s.text(1017,345,'Individual billing arrangement',13,MUTED)
 s.line(1017,371,1320,371);s.text(1017,404,'Needs attention',13,AMBER,600)
 s.icon('water',1017,430,'#438096',24);s.text(1055,450,'Manila Water',18,weight=600)
 s.text(1017,494,'₱283.97',31,weight=600);s.text(1017,526,'Extracted due date: unreadable',13,AMBER)
 s.rect(1017,552,303,102,PALE,5);s.text(1031,579,'Source shows',12,MUTED);s.text(1031,608,'28 October 2026',19,weight=600)
 s.text(1031,636,'Proposal pending' if role=='Manager' else 'Correction not yet submitted',12,MUTED)
 s.button(1017,683,303,'Review correction' if role=='Manager' else 'Prepare correction')
 s.text(1017,771,'Open unit record  ›',13,BLUE,600)
 return s

def phone_shell(s):
 s.rect(0,0,430,1280,BG);s.rect(0,0,430,74,NAVY);s.icon('menu',24,26,'white',23);s.logo(142,21,size=32);s.text(180,48,'Rentara',23,'white',600);s.icon('bell',383,26,'white',23)
def bottom(s):
 s.rect(0,1204,430,76,'#e5edf5');s.line(0,1204,430,1204)
 for x,key,label in [(54,'home','Home'),(161,'bill','Bills'),(269,'bell','Alerts'),(376,'settings','Settings')]:
  s.icon(key,x-12,1218,BLUE if key=='home' else MUTED,24);s.text(x,1261,label,12,BLUE if key=='home' else MUTED,600 if key=='home' else 400,'middle')

def cal(s,y,small=False):
 s.text(24,y,'October 2026',21,weight=600);s.text(406,y,'‹     ›',24,MUTED,anchor='end')
 start=y+39;cell=54.57;rh=37 if small else 42
 for i,d in enumerate(['M','T','W','T','F','S','S']):s.text(51+i*cell,start,d,12,MUTED,anchor='middle')
 for r,week in enumerate(calendar.monthcalendar(2026,10)):
  for c,day in enumerate(week):
   if not day:continue
   x=51+c*cell;yy=start+29+r*rh
   if day in [27,28,30]:s.rect(x-22,yy-18,44,36,BLUE if day==30 else '#e1edf4',5)
   s.text(x,yy,day,13,'white' if day==30 else INK,600 if day in [27,28,30] else 400,'middle')
   if day in [27,28,30]:s.icon({27:'bolt',28:'water',30:'home'}[day],x-6,yy+3,'white' if day==30 else '#486e83',12)
 return start+29+4*rh+32

def utility(s,y,label,amount,due,ico,compact=False):
 s.icon(ico,24,y+2,'#956c1b' if ico=='bolt' else '#438096',23)
 s.text(61,y+17,label,16,weight=600);s.text(406,y+17,amount,19,weight=600,anchor='end')
 s.text(61,y+43,'Due '+due+' · Not marked paid',12,MUTED)
 s.button(61,y+60,345,'Mark personally paid',False,h=44)
 s.line(24,y+120,406,y+120)

def phone(mode):
 s=SVG(mode+' · Tenant mobile',430,1280);phone_shell(s)
 if mode=='A':
  s.text(24,126,'Hello, Maria.',34,serif=True);s.text(24,158,'Riverside Apartments · Unit 1A',14,MUTED)
  s.line(24,189,406,189,BLUE,2);s.text(24,224,'October rent',15,MUTED);s.tag(326,204,'Unpaid',color='#9b4a40',fill='#f6e9e6',w=80)
  s.text(22,286,'₱6,000.00',49,weight=600);s.text(24,321,'Due October 30, 2026',16,MUTED)
  s.button(24,350,382,'Report rent payment',h=48);s.text(24,425,'Manager confirms rent payments.',12,MUTED)
  s.text(24,472,'Personal utility tracker',24,serif=True)
  utility(s,498,'Meralco','₱850.00','Oct 27','bolt');utility(s,638,'Manila Water','₱283.97','Oct 28','water')
  s.text(24,797,'Personal marks. Provider payment not verified.',12,MUTED)
  s.text(24,843,'Your due dates',24,serif=True);end=cal(s,884,True)
  s.text(24,end+8,'⌂  Rent    ϟ  Electricity    ◇  Water',12,MUTED)
  s.text(24,1171,'Nov 30 · Rent estimate, not yet billed',12,MUTED)
 elif mode=='B':
  s.text(24,114,'Riverside Apartments · Unit 1A',13,MUTED);s.text(24,155,'Hello, Maria.',29,weight=500)
  s.rect(24,185,382,198,'white',8);s.date(43,211,'30',dark=True)
  s.text(110,226,'October rent',14,MUTED);s.text(108,270,'₱6,000.00',38,weight=600)
  s.text(110,302,'Unpaid · due Oct 30, 2026',13,'#9b4a40');s.button(42,324,346,'Report rent payment',h=44)
  s.text(24,412,'Manager confirms rent payments.',12,MUTED);s.text(24,465,'Utilities · your own tracking',19,weight=600)
  utility(s,491,'Meralco','₱850.00','Oct 27','bolt');utility(s,631,'Manila Water','₱283.97','Oct 28','water')
  s.text(24,789,'Provider payment not verified.',12,MUTED)
  s.text(24,842,'Coming up',23,weight=600);s.text(406,842,'Month view ›',13,BLUE,600,'end')
  for y,day,label,amount,ico in [(873,'27','Meralco','₱850.00','bolt'),(955,'28','Manila Water','₱283.97','water'),(1037,'30','Rent','₱6,000.00','home')]:
   s.date(24,y,day);s.icon(ico,87,y+15,size=20);s.text(119,y+27,label,15,weight=600);s.text(406,y+28,amount,15,weight=600,anchor='end')
  s.text(24,1167,'Nov 30 · Rent estimate, not yet billed',12,MUTED)
 else:
  s.text(24,117,'Maria Reyes · Unit 1A',14,MUTED);s.text(24,159,'October statement',30,weight=600)
  s.rect(0,184,430,224,'#e0ebf5');s.text(24,221,'Rent',17,weight=600);s.tag(326,200,'Unpaid',color='#9b4a40',fill='#f6e9e6',w=80)
  s.text(24,278,'₱6,000.00',47,weight=600);s.text(24,312,'Due October 30, 2026',15,MUTED);s.button(24,338,382,'Report rent payment',h=46)
  s.text(24,440,'Manager confirms rent payments.',12,MUTED);s.text(24,487,'Personal utility tracker',21,weight=600)
  utility(s,513,'Meralco','₱850.00','Oct 27','bolt');utility(s,650,'Manila Water','₱283.97','Oct 28','water')
  s.text(24,806,'Provider payment not verified.',12,MUTED);s.text(24,853,'Due-date calendar',21,weight=600)
  end=cal(s,898,True);s.text(24,1178,'Nov 30 · Rent estimate, not yet billed',12,MUTED)
 bottom(s);return s

def board(key,name,description,manager,staff,mobile):
 s=SVG(key+' · '+name+' comparison',1850,1840);s.rect(0,0,1850,1840,'#e7edf3')
 s.text(22,35,key+' / '+name,27,weight=600);s.text(22,61,description,14,MUTED)
 s.text(22,91,'Manager · shared workspace',14,weight=600);s.text(1410,91,'Tenant · after validation',14,weight=600)
 for x,y,obj in [(22,108,manager),(22,992,staff),(1410,108,mobile)]:
  raw=obj.finish();raw=raw.replace('width="'+str(obj.w)+'" height="'+str(obj.h)+'"',f'x="{x}" y="{y}" width="{obj.w}" height="{obj.h}"',1);s.p.append(raw)
 s.text(22,978,'Staff · same shell and page structure, permitted actions change',14,weight=600)
 s.text(1410,1437,'One application.',23,serif=True);s.text(1410,1470,'The role controls the actions.',16,weight=600)
 for j,line in enumerate(['Shared navigation and page components.','Staff prepares; Manager authorizes.','Tenant sees only their own records.','Admin maintains accounts and workspaces.','No Admin rent approval or impersonation.']):s.text(1410,1510+j*30,line,13,MUTED)
 s.text(1410,1670,'Views show different workflow stages.',13,MUTED)
 s.text(1410,1710,'Visual proposal only.',14,weight=600);s.text(1410,1738,'Fictional data · not implemented',13,MUTED)
 return s

def main():
 specs=[('A','Rental folio','An editorial task ledger with a narrow bill context column.',folio),('B','Review desk','A queue, original document and correction pane on one working surface.',review_desk),('C','Property register','A property-first unit register with a selected-record inspector.',register)]
 manifest=[]
 for key,name,desc,fn in specs:
  screens={'manager':fn('Manager'),'staff':fn('Staff'),'tenant':phone(key)}
  for role,obj in screens.items():(ROOT/f'{key.lower()}-{role}.svg').write_text(obj.finish(),encoding='utf-8')
  (ROOT/f'{key.lower()}-comparison.svg').write_text(board(key,name,desc,*screens.values()).finish(),encoding='utf-8')
  manifest.append({'key':key.lower(),'name':name,'description':desc,'screens':list(screens),'board':f'{key.lower()}-comparison.png'})
 (ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
 print('Created 9 role screens and 3 comparison boards. Portal unchanged.')
if __name__=='__main__':main()
