import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readdir,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
const require=createRequire(new URL('../../../rentara-portal/package.json',import.meta.url));
const {chromium}=require('@playwright/test');
const browser=await chromium.launch({headless:true,...(process.platform==='win32'?{executablePath:process.env.BROWSER_EXECUTABLE||'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'}:{})});
const audits=[];
try{
 const page=await browser.newPage({deviceScaleFactor:1,reducedMotion:'reduce'});
 await page.route(/^https?:/,r=>r.abort());
 for(const file of (await readdir(new URL('.',import.meta.url))).filter(n=>/^[abc]-.+\.svg$/.test(n)).sort()){
  await page.goto(new URL(file,import.meta.url).href);await page.evaluate(()=>document.fonts.ready);
  const audit=await page.evaluate(()=>{
   const root=document.documentElement,rect=root.getBoundingClientRect(),box=root.viewBox.baseVal;
   return {width:box.width,height:box.height,errors:document.querySelectorAll('parsererror').length,
    outside:[...document.querySelectorAll('text')].filter(el=>{const b=el.getBoundingClientRect();return b.left<rect.left-1||b.top<rect.top-1||b.right>rect.right+1||b.bottom>rect.bottom+1}).map(el=>el.textContent)};
  });
  assert.equal(audit.errors,0,file);assert.deepEqual(audit.outside,[],file);
  await page.setViewportSize({width:audit.width,height:audit.height});
  await page.screenshot({path:fileURLToPath(new URL(file.replace('.svg','.png'),import.meta.url)),animations:'disabled'});
  audits.push({file,...audit});
 }
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto(new URL('index.html',import.meta.url).href);
 for(const direction of ['a','b','c'])for(const role of ['manager','staff','tenant','comparison']){
  await page.locator(`[data-direction="${direction}"]`).click();await page.locator(`[data-role="${role}"]`).click();
  await page.locator('#preview').evaluate(image=>image.decode());
  assert.ok((await page.locator('#preview').getAttribute('src'))===`${direction}-${role}.png`);
 }
 assert.deepEqual(errors,[]);
 await writeFile(new URL('render-audit.json',import.meta.url),JSON.stringify({externalRequests:'blocked',screens:audits,viewerStates:12,viewerErrors:errors},null,2));
 console.log(`Rendered ${audits.length} SVG/PNG mockups and checked all 12 viewer selections.`);
}finally{await browser.close();}
