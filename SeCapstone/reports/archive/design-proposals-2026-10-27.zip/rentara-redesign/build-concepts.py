"""Offline vector concepts. Does not load the application, credentials or data."""
from pathlib import Path
from html import escape
import calendar

ROOT = Path(__file__).resolve().parent
INK = '#18344b'
MUTED = '#5d7387'
BLUE = '#315ed1'
NAVY = '#173d59'
PALE = '#e9f0f7'
BG = '#f3f6fa'
LINE = '#dce5ee'
PESO = '\u20b1'
ARROW = '\u2192'

ICONS = {
 'home':'<path d="m3 10 9-7 9 7M5 9v12h14V9M9 21v-7h6v7"/>',
 'building':'<path d="M4 21V4h10v17M14 10h6v11M2 21h20M7 8h4M7 12h4M7 16h4M17 14h1M17 17h1"/>',
 'units':'<path d="M4 21h16M7 21V4l10-2v19M7 4h10"/><circle cx="13" cy="12" r=".6"/>',
 'people':'<circle cx="9" cy="8" r="3.5"/><path d="M3 21v-2a6 6 0 0 1 12 0v2M16 5a3.5 3.5 0 0 1 0 7M21 21v-2a6 6 0 0 0-4-5"/>',
 'bill':'<path d="M5 21V3h14v18l-3-2-4 2-4-2zM8 8h8M8 12h8M8 16h4"/>',
 'chart':'<path d="M3 3v18h18M7 16v-5M12 16V7M17 16v-7"/>',
 'settings':'<path d="M3 6h18M3 12h18M3 18h18"/><circle cx="9" cy="6" r="2"/><circle cx="15" cy="12" r="2"/><circle cx="9" cy="18" r="2"/>',
 'logout':'<path d="M9 4H4v16h5M10 12h11M17 8l4 4-4 4"/>',
 'search':'<circle cx="10" cy="10" r="6.5"/><path d="m15 15 5 5"/>',
 'bell':'<path d="M5 17h14l-2-3V9a5 5 0 0 0-10 0v5zM10 21h4"/>',
 'arrow':'<path d="M4 12h16m-6-6 6 6-6 6"/>',
 'chevron':'<path d="m9 6 6 6-6 6"/>',
 'file':'<path d="M6 21V3h8l4 4v14zM14 3v5h4M9 12h6M9 16h6"/>',
 'check':'<path d="m5 12 4 4L19 6"/>',
 'upload':'<path d="M4 16v5h16v-5M12 16V3m-5 5 5-5 5 5"/>',
 'bolt':'<path d="m13 2-8 12h6l-1 8 9-13h-7z"/>',
 'water':'<path d="M12 2C9 7 5 11 5 15a7 7 0 0 0 14 0c0-4-4-8-7-13z"/>',
 'menu':'<path d="M3 6h18M3 12h18M3 18h18"/>',
 'lock':'<rect x="5" y="10" width="14" height="11" rx="2"/><path d="M8 10V6a4 4 0 0 1 8 0v4"/>',
}

class SVG:
 def __init__(self, title, w=1600, h=1080):
  self.w,self.h=w,h
  self.p=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}" role="img" aria-labelledby="title desc"><title id="title">{escape(title)}</title><desc id="desc">Rentara visual proposal only. Fictional records. Existing role and billing scope. Not implemented in the portal.</desc><g font-family="Segoe UI,Arial,sans-serif" style="font-variant-numeric:tabular-nums">']
 def raw(self,s):self.p.append(s)
 def rect(self,x,y,w,h,fill='white',r=0,stroke='none'):
  self.raw(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}"/>')
 def text(self,x,y,t,s=16,c=INK,b=400,a='start',serif=False):
  family='Georgia,serif' if serif else 'Segoe UI,Arial,sans-serif'
  self.raw(f'<text x="{x}" y="{y}" fill="{c}" font-size="{s}" font-weight="{b}" text-anchor="{a}" font-family="{family}">{escape(str(t))}</text>')
 def line(self,x,y,x2,y2,c=LINE):self.raw(f'<path d="M{x} {y}L{x2} {y2}" fill="none" stroke="{c}"/>')
 def icon(self,k,x,y,size=21,c=MUTED):
  self.raw(f'<svg x="{x}" y="{y}" width="{size}" height="{size}" viewBox="0 0 24 24" fill="none" stroke="{c}" stroke-width="1.7" stroke-linejoin="round" stroke-linecap="round">{ICONS[k]}</svg>')
 def logo(self,x,y,size=40,c='white'):
  self.raw(f'<svg x="{x}" y="{y}" width="{size}" height="{size}" viewBox="0 0 64 64"><path d="M17 53V23L32 11l16 12v9c0 7-5 11-12 11H20m13 0 15 10M19 28h15a7 7 0 0 1 0 14" fill="none" stroke="{c}" stroke-width="5" stroke-linecap="round" stroke-linejoin="round"/></svg>')
 def button(self,x,y,w,label,primary=True,icon=None):
  self.rect(x,y,w,46,BLUE if primary else 'white',9,'none' if primary else LINE)
  if icon:self.icon(icon,x+15,y+13,19,'white' if primary else BLUE)
  self.text(x+(42 if icon else w/2),y+29,label,15,'white' if primary else INK,600,'start' if icon else 'middle')
 def link(self,x,y,t):self.text(x,y,t,14,BLUE,600)
 def pill(self,x,y,t,w=110,c=BLUE,bg=PALE):
  self.rect(x,y,w,27,bg,6);self.text(x+10,y+18,t,12,c,600)
 def roof(self,x,y,scale=1,c='#a8c0d5'):
  # Decorative architecture only, not a live floorplan or unit map.
  self.raw(f'<g transform="translate({x} {y}) scale({scale})" fill="none" stroke="{c}" stroke-width="1.5" stroke-linejoin="round"><path d="M0 128H352M19 128V45l66-35 64 35v83M149 128V59l76-39 79 39v69M19 45l66 29 64-29M85 74v54M149 59l76 34 79-34M225 93v35"/><path d="M35 61v22l30 13V74zM35 96v20l30 12V108zM105 74v22l26-12V61zM105 108v20l26-12V96zM167 76v23l38 16V92zM245 93v23l40-18V75z"/><path d="M317 128V86m-12 24 12-24 13 24M10 128V97m-7 15 7-15 8 15"/></g>')
 def building(self,x,y,scale=1):
  self.raw(f'<g transform="translate({x} {y}) scale({scale})"><path d="M0 57 35 69 80 47 45 35z" fill="#dce7f1"/><path d="M8 20 34 7l34 12-26 14z" fill="#9fb8d1"/><path d="M8 20v34l34 13V33z" fill="#c7d8e8"/><path d="M42 33v34l26-14V19z" fill="#e0eaf3"/><path d="M17 28v10l9 3V31zM17 43v9l9 4V46zM30 33v10l7 3V36zM49 36v10l10-5V31zM49 51v10l10-5V46z" fill="#6f92b6"/><path d="M32 49v13l5 2V51z" fill="#355e85"/></g>')
 def shell(self,role='Manager',active='Dashboard'):
  self.rect(0,0,self.w,self.h,BG);self.rect(0,0,220,self.h,NAVY);self.rect(220,0,self.w-220,72,'#e5edf5')
  self.logo(23,22,37);self.text(70,49,'Rentara',25,'white',650);self.text(31,91,role+' workspace',12,'#b8cedf')
  menus={
   'Manager':[('home','Dashboard'),('building','Properties'),('units','Units'),('people','Tenants'),('bill','Bills & Payments'),('chart','Reports'),('settings','Settings')],
   'Staff':[('home','Daily operations'),('building','Properties'),('units','Units'),('people','Tenants'),('bill','Bills & Payments'),('settings','Account')],
   'Tenant':[('home','My home'),('bill','My bills'),('bell','Notifications'),('settings','Settings')],
   'Admin':[('home','Dashboard'),('file','Audit log'),('settings','Settings')],
  }
  for i,(k,label) in enumerate(menus[role]):
   yy=151+i*55
   if label==active:self.rect(14,yy-25,192,45,'#2e5676',8);self.rect(14,yy-13,3,21,'#b5d1f2',1)
   self.icon(k,29,yy-12,20,'#c3d5e5');self.text(66,yy+4,label,14,'white' if label==active else '#c9d8e6',600 if label==active else 400)
  self.line(28,self.h-153,192,self.h-153,'#33546d');self.icon('logout',30,self.h-128,20,'#c3d5e5');self.text(66,self.h-112,'Sign out',14,'#d5e1ec')
  name={'Manager':'Alex Mendoza','Staff':'Lea Santos','Tenant':'Maria Reyes','Admin':'System admin'}[role]
  self.rect(28,self.h-74,35,35,'#335b79',9);self.text(45.5,self.h-51,''.join(w[0] for w in name.split()[:2]),12,'white',600,'middle');self.text(76,self.h-60,name,13,'white',600);self.text(76,self.h-40,role,12,'#bfd0e0')
  self.text(277,44,'Rentara administration' if role=='Admin' else 'Riverside management' if role!='Tenant' else 'Riverside Apartments / Unit 1A',14,'#45627c',500)
  self.rect(1130,17,325,39,'#f8fbfd',8);self.icon('search',1143,28,17,'#7890a5');self.text(1172,42,'Search the portal...',13,'#7990a5');self.icon('bell',1492,25,22,'#46617a')
  self.text(self.w-34,self.h-15,'Visual proposal / Fictional data',10,'#8092a4',400,'end')
 def heading(self,title,sub,eyebrow=''):
  if eyebrow:self.text(277,116,eyebrow,13,MUTED,500)
  self.text(277,170,title,44,INK,400,serif=True);self.text(279,204,sub,16,MUTED)
 def save(self,name):
  (ROOT/name).write_text('\n'.join(self.p)+ '\n</g></svg>\n',encoding='utf-8')

def manager():
 s=SVG('Rentara redesigned Manager workspace');s.shell();s.heading('Your workspace.','Three decisions are ready for your review.','Welcome back, Alex')
 s.roof(1180,100,.83,'#adc2d6')
 s.button(279,232,187,'Review decisions',icon='arrow');s.link(493,260,'Open bill intake')
 for x,label,value in [(280,'Units','16'),(532,'Active tenants','24'),(803,'Outstanding rent and advance',PESO+'18,450.00')]:
  s.text(x,338,label,13,MUTED);s.text(x,377,value,31,INK,600)
 s.line(280,408,1540,408);s.text(280,455,'Ready for your review',25,INK,400,serif=True);s.text(1008,453,'3 items',13,MUTED,400,'end')
 rows=[('01','Water bill correction','Unit 2B / Prepared by Lea Santos','Due date: Oct 22 '+ARROW+' Oct 30','Review proposal'),('02','Rent payment report','Unit 1A / Maria Reyes',PESO+'6,000.00 / Awaiting confirmation','Review report'),('03','Utility account needs linking','Unit 3C / Escalated by Staff','Manager setup required','Review case')]
 for i,(n,title,sub,detail,action) in enumerate(rows):
  y=486+i*117
  if i==0:s.rect(279,y,745,105,'white',12)
  s.text(299,y+35,n,17,'#7895b2',400,serif=True);s.text(349,y+34,title,17,INK,600);s.text(349,y+59,sub,14,MUTED);s.text(349,y+84,detail,13,MUTED);s.text(991,y+57,action,13,BLUE,600,'end');s.line(349,y+112,1008,y+112)
 s.rect(1070,435,470,393,'#e6eef6',16);s.text(1100,478,'Your properties',25,INK,400,serif=True);s.link(1455,477,'View all')
 for y,name,occupancy,rent in [(521,'Riverside Apartments','8 of 10 units occupied',PESO+'32,000 / month'),(656,'Maple Court Homes','4 of 6 units occupied',PESO+'20,000 / month')]:
  s.building(1093,y,0.9);s.text(1189,y+25,name,17,INK,600);s.text(1189,y+52,occupancy,13,MUTED);s.text(1189,y+80,rent,13,MUTED)
 s.text(280,916,'Around your workspace',25,INK,400,serif=True);s.link(1469,914,'View activity')
 for x,k,title,detail in [(280,'check','Utility bill finalized','Electricity / Unit 2B / 10:42 AM'),(725,'bill','Rent payment confirmed','Maria Reyes / Unit 1A / 9:18 AM'),(1182,'file','Correction returned','Water / Unit 3C / Yesterday')]:
  s.icon(k,x,951,20,'#718eaa');s.text(x+31,967,title,15,INK,600);s.text(x+31,994,detail,12,MUTED)
 s.save('02-manager.svg')

def login():
 s=SVG('Rentara redesigned sign-in');s.rect(0,0,1600,1080,BG);s.rect(28,28,770,1024,NAVY,24)
 s.logo(76,67,42);s.text(134,98,'Rentara',29,'white',650)
 s.text(89,278,'A clearer view',61,'white',400,serif=True);s.text(89,354,'of home.',61,'white',400,serif=True)
 s.text(92,412,'Rent, utility bills and the details that matter.',18,'#c8d9e7')
 s.roof(95,549,1.72,'#7ba0bf');s.text(91,983,'For the people who manage homes.',16,'#c1d3e2')
 s.text(943,228,'Welcome back.',45,INK,400,serif=True);s.text(946,268,'Sign in to your Rentara account.',17,MUTED)
 for y,label,value in [(344,'Email address','you@example.com'),(450,'Password','Enter your password')]:
  s.text(946,y,label,14,INK,600);s.rect(945,y+15,438,56,'white',9,LINE);s.text(963,y+50,value,16,'#8093a5')
 s.text(1380,563,'Need help? Contact your manager.',14,MUTED,400,'end');s.button(945,599,438,'Sign in')
 s.icon('lock',946,686,17,'#738ba0');s.text(976,701,'Your account determines your access.',14,MUTED)
 s.line(945,761,1383,761);s.text(945,798,'Need an account?',16,INK,600);s.text(945,827,'Ask your property manager to help you get started.',14,MUTED)
 s.text(1540,1044,'Design concept / Fictional sample data',11,'#8092a4',400,'end');s.save('01-login.svg')

def staff():
 s=SVG('Rentara redesigned Staff daily operations');s.shell('Staff','Daily operations');s.heading('A place to start.','Investigate flagged bills and prepare corrections.','Daily operations')
 s.roof(1201,108,.78);s.button(279,233,173,'Upload bill',icon='upload');s.link(480,261,'Check mailbox')
 for x,label,count,active in [(280,'Needs action','4',True),(532,'With Manager','2',False),(805,'Returned','1',False)]:
  s.text(x,340,label,15,BLUE if active else MUTED,600 if active else 400);s.text(x+159,340,count,22,BLUE if active else INK,600)
  if active:s.line(x,360,x+205,360,BLUE)
 s.rect(279,390,819,568,'white',17);s.text(310,435,'Bills that need a closer look',25,INK,400,serif=True)
 rows=[('water','Due date unreadable','Manila Water / Unit 2B','Compare the original and propose the correct date.','Prepare correction'),('file','Utility account is not linked','Meralco / Account G3-0104','Add your findings. Manager handles account mapping.','Add findings'),('lock','PDF requires a password','Manila Water / invoice.pdf','Open locally and upload a readable copy.','View source'),('bill','Possible duplicate bill','Meralco / Unit 1A','Compare it with the existing bill before proceeding.','View source')]
 for i,(k,title,sub,detail,action) in enumerate(rows):
  y=479+i*111;s.icon(k,311,y-1,23,'#718da8');s.text(351,y+12,title,17,INK,600);s.text(351,y+37,sub,14,MUTED);s.text(351,y+62,detail,12,MUTED);s.text(1067,y+35,action,13,BLUE,600,'end')
  if i<3:s.line(351,y+86,1065,y+86)
 s.text(1150,427,'Intake, at a glance',26,INK,400,serif=True)
 s.text(1152,479,'Automatic processing',15,INK,600);s.text(1152,508,'Valid bills continue automatically.',14,MUTED)
 s.line(1151,542,1540,542);s.text(1152,578,'Last mailbox check',13,MUTED);s.text(1152,609,'Today, 1:05 PM',19,INK,500);s.text(1152,642,'Next eligible check: 1:10 PM',13,MUTED)
 s.line(1151,678,1540,678);s.text(1152,718,'You prepare. Manager decides.',21,INK,400,serif=True);s.text(1152,751,'Proposals keep live billing unchanged',14,MUTED);s.text(1152,776,'until authorized and revalidated.',14,MUTED)
 s.text(280,1008,'Start with the original bill. Keep the reason with every correction.',14,MUTED);s.save('03-staff.svg')

def due_calendar(s,x,y,w=480):
 s.rect(x,y,w,400,'white',17)
 s.text(x+24,y+36,'October 2026',22,INK,400,serif=True);s.text(x+w-70,y+35,'\u2039',25,MUTED);s.text(x+w-35,y+35,'\u203a',25,MUTED)
 cw=(w-40)/7
 for i,name in enumerate(['M','T','W','T','F','S','S']):s.text(x+20+cw*(i+.5),y+78,name,12,MUTED,500,'middle')
 for day in range(1,32):
  index=day+2;col=index%7;row=index//7;cx=x+20+cw*col;cy=y+95+row*48
  if day in [27,28,30]:s.rect(cx+3,cy-1,cw-6,43,BLUE if day==30 else '#e6eff8' if day==27 else '#e3f0f3',8)
  s.text(cx+cw/2,cy+16,day,13,'white' if day==30 else INK,600 if day in [23,27,28,30] else 400,'middle')
  if day in [27,28,30]:s.icon('bolt' if day==27 else 'water' if day==28 else 'home',cx+cw/2-7,cy+21,14,'white' if day==30 else '#8c681d' if day==27 else '#407b8f')
  if day==23:s.line(cx+cw/2-7,cy+26,cx+cw/2+7,cy+26,BLUE)
 for offset,k,label in [(22,'home','Rent'),(w/3+5,'bolt','Electricity'),(2*w/3,'water','Water')]:s.icon(k,x+offset,y+357,16,BLUE if k=='home' else MUTED);s.text(x+offset+23,y+371,label,12,MUTED)

def tenant():
 s=SVG('Rentara redesigned Tenant home');s.shell('Tenant','My home');s.heading('Hello, Maria.','Your rent, utilities and the dates ahead.','Riverside Apartments / Unit 1A');s.roof(1190,104,.8)
 s.rect(279,260,701,307,'#e4edf7',20);s.text(310,306,'October rent',16,INK,600);s.pill(853,282,'Unpaid',91,'#9b4a40','#f6e9e6')
 s.text(310,383,PESO+'6,000.00',54,INK,600);s.text(313,419,'Due October 30, 2026',17,MUTED)
 s.roof(716,332,.57,'#a0b9d2');s.button(311,456,276,'Report rent payment');s.link(614,486,'View bill');s.text(313,538,'Manager confirms rent payments.',13,MUTED)
 s.text(280,624,'Personal utility tracker',27,INK,400,serif=True)
 for y,k,provider,category,amount,due in [(665,'bolt','Meralco','Electricity',PESO+'850.00','Oct 27'),(811,'water','Manila Water','Water',PESO+'220.00','Oct 28')]:
  s.rect(279,y-15,701,126,'white',14);s.rect(302,y+6,43,43,'#f7efd9' if k=='bolt' else '#e4eff5',12);s.icon(k,312,y+16,23,'#94711d' if k=='bolt' else '#4a7e96')
  s.text(364,y+20,provider,17,INK,600);s.text(364,y+47,category+' / Due '+due,13,MUTED);s.text(364,y+80,amount,22,INK,600)
  s.text(949,y+16,'Not marked paid',12,MUTED,400,'end');s.button(722,y+44,227,'Mark personally paid',False)
 s.text(281,978,'These are personal marks. Provider payment is not verified.',13,MUTED)
 s.text(1034,298,'Your due dates',26,INK,400,serif=True);due_calendar(s,1034,327,506)
 s.text(1038,763,'Next rent: Nov 30 (estimate)',14,MUTED);s.text(1038,791,'Utility dates come from received bills.',12,MUTED)
 s.text(1035,855,'Latest updates',25,INK,400,serif=True);s.text(1038,900,'Your water bill is ready',16,INK,600);s.text(1038,927,'Due Oct 28 / '+PESO+'220.00',13,MUTED);s.link(1038,982,'View notifications '+ARROW);s.save('04-tenant.svg')

def tenant_mobile():
 s=SVG('Rentara redesigned Tenant home - full mobile concept',430,1440);s.rect(0,0,430,1440,BG);s.rect(0,0,430,76,NAVY)
 s.icon('menu',21,27,23,'white');s.logo(128,21,34);s.text(170,47,'Rentara',24,'white',650);s.icon('bell',383,26,23,'#d4e2ed')
 s.text(25,135,'Hello, Maria.',36,INK,400,serif=True);s.text(27,170,'Riverside Apartments / Unit 1A',14,MUTED)
 s.rect(24,200,382,281,'#e4edf7',20);s.text(45,238,'October rent',15,INK,600);s.pill(306,220,'Unpaid',79,'#9b4a40','#f6e9e6')
 s.text(43,309,PESO+'6,000.00',47,INK,600);s.text(45,344,'Due October 30, 2026',15,MUTED);s.button(44,377,342,'Report rent payment');s.text(45,458,'Manager confirms rent payments.',12,MUTED)
 s.text(25,530,'Personal utility tracker',25,INK,400,serif=True)
 for y,k,provider,amount,due in [(561,'bolt','Meralco',PESO+'850.00','Oct 27'),(714,'water','Manila Water',PESO+'220.00','Oct 28')]:
  s.icon(k,27,y+4,26,'#94711d' if k=='bolt' else '#4a7e96');s.text(69,y+16,provider,16,INK,600);s.text(69,y+43,amount,22,INK,600);s.text(403,y+17,'Due '+due,13,MUTED,400,'end');s.text(403,y+44,'Not marked paid',12,MUTED,400,'end');s.button(70,y+65,239,'Mark personally paid',False);s.line(25,y+132,404,y+132)
 s.text(27,884,'Personal marks / Provider payment not verified.',12,MUTED)
 s.text(25,933,'Your due dates',25,INK,400,serif=True);due_calendar(s,24,948,382)
 s.rect(0,1364,430,76,'#e5edf5');s.line(0,1364,430,1364,'#d6e1ec')
 for i,(k,label) in enumerate([('home','Home'),('bill','Bills'),('bell','Alerts'),('settings','Settings')]):
  cx=53.75+107.5*i;s.icon(k,cx-12,1379,24,BLUE if i==0 else MUTED);s.text(cx,1422,label,12,BLUE if i==0 else MUTED,600 if i==0 else 400,'middle')
 s.save('05-tenant-mobile.svg')

def admin():
 s=SVG('Rentara redesigned Admin accounts and workspaces');s.shell('Admin','Settings');s.heading('People & workspaces.','Manage access while keeping each business separate.','Administration');s.roof(1201,106,.78)
 s.button(279,234,175,'Add account',icon='people');s.link(485,263,'View workspaces')
 for x,label,value in [(280,'Accounts','30'),(560,'Workspaces','2'),(839,'Roles','4')]:s.text(x,337,label,14,MUTED);s.text(x,378,value,33,INK,600)
 s.line(280,408,1540,408);s.text(280,458,'Account directory',26,INK,400,serif=True)
 s.rect(279,482,780,46,'white',9);s.icon('search',293,495,18);s.text(325,511,'Search a name or email',14,'#8093a5');s.text(1090,511,'All roles',14,INK);s.text(1241,511,'All workspaces',14,INK);s.text(1453,511,'Active',14,INK)
 for x,label in [(280,'Name'),(687,'Role'),(865,'Workspace'),(1230,'Status')]:s.text(x,578,label,12,MUTED,500)
 s.line(280,597,1540,597)
 rows=[('Alex Mendoza','alex@example.test','Manager','Riverside management'),('Lea Santos','lea@example.test','Staff','Riverside management'),('Maria Reyes','maria@example.test','Tenant','Riverside management'),('Paolo Ramos','paolo@example.test','Manager','Eastbank rentals')]
 for i,(name,email,role,workspace) in enumerate(rows):
  y=638+i*81;s.text(280,y,name,17,INK,600);s.text(280,y+25,email,13,MUTED);s.text(687,y+7,role,14,INK);s.text(865,y+7,workspace,14,MUTED);s.text(1230,y+7,'Active',13,'#497867');s.link(1412,y+7,'Manage');s.line(280,y+49,1540,y+49)
 s.text(280,1009,'Account management does not sign you in as another user.',14,MUTED);s.save('06-admin.svg')

def billing():
 s=SVG('Rentara redesigned billing register');s.shell('Manager','Bills & Payments');s.heading('The billing record.','Rent and utility records, with the right status for each.','Bills & payments');s.button(1350,137,190,'Open bill intake')
 for x,label,active in [(280,'Incoming bills',False),(493,'Billing records',True),(709,'Rent payments',False),(932,'Exceptions',False)]:
  s.text(x,286,label,15,BLUE if active else MUTED,600 if active else 400)
  if active:s.line(x,305,x+158,305,BLUE)
 s.rect(280,337,525,46,'white',9);s.icon('search',295,351,18);s.text(327,367,'Search a tenant, unit or reference',14,'#8093a5');s.text(846,367,'All categories',14,INK);s.text(1062,367,'All statuses',14,INK);s.link(1432,367,'Export CSV')
 s.text(280,430,'October 2026',25,INK,400,serif=True);s.text(1538,429,'24 records',13,MUTED,400,'end')
 for x,label in [(280,'Tenant / unit'),(666,'Category'),(871,'Due date'),(1090,'Amount'),(1212,'Status')]:s.text(x,483,label,12,MUTED,500)
 s.line(280,502,1540,502)
 rows=[('Maria Reyes','Unit 1A','Rent','Oct 30',PESO+'6,000.00','Awaiting confirmation','Review report'),('Carlo Lim','Unit 2B','Electricity','Oct 27',PESO+'850.00','Not marked paid','View bill'),('Bea Cruz','Unit 3C','Water','Oct 28',PESO+'220.00','Self-reported paid','View bill'),('Nina Aquino','Unit 1B','Rent','Oct 30',PESO+'6,000.00','Unpaid','View bill'),('Maria Reyes','Unit 1A','Rent','Sep 30',PESO+'6,000.00','Confirmed rent','View receipt')]
 for i,(name,unit,category,due,amount,status,action) in enumerate(rows):
  y=547+i*84
  if i==0:s.rect(267,y-23,1287,76,'white',9)
  s.text(280,y,name,16,INK,600);s.text(280,y+25,unit,13,MUTED);s.text(666,y+8,category,14,MUTED);s.text(871,y+8,due,14,MUTED);s.text(1090,y+8,amount,16,INK,600,'end');s.text(1212,y+8,status,12,BLUE if i==0 else MUTED);s.text(1538,y+8,action,13,BLUE,600,'end');s.line(280,y+54,1540,y+54)
 s.text(280,1015,'Manager confirms rent. Utility marks are personal; provider payment is not verified.',13,MUTED);s.save('07-billing.svg')

def correction(manager_view=False):
 s=SVG('Rentara redesigned correction '+('decision' if manager_view else 'preparation'));s.shell('Manager' if manager_view else 'Staff','Bills & Payments');s.heading('A closer look.','Compare the original bill with the proposed correction.','Bills / Corrections')
 s.link(1378,148,'Back to exceptions')
 # A fictional original document provides context, without copying private bills.
 s.rect(279,258,658,724,'#e7edf4',18);s.text(307,298,'Original bill',14,INK,600);s.text(908,298,'PDF / 1 page',12,MUTED,400,'end')
 s.rect(333,326,550,610,'white',3);s.text(368,378,'SYNTHETIC UTILITY BILL',12,'#75889b',500);s.text(368,430,'Manila Water',32,INK,400,serif=True);s.line(368,456,848,456)
 for y,label,value in [(503,'Account / CAN','TEST-WATER-002'),(568,'Billing period','Sep 23 to Oct 22, 2026'),(633,'Total amount due',PESO+'283.97'),(698,'Due date','October 30, 2026')]:s.text(368,y,label,12,MUTED);s.text(368,y+29,value,18,INK,600)
 s.text(368,826,'Illustrative bill / No real account details',12,'#8393a3');s.link(307,1011,'Download original')
 s.text(991,295,'Prepared correction' if manager_view else 'Prepare a correction',29,INK,400,serif=True)
 s.text(993,333,'Unit 2B / Manila Water',14,MUTED)
 s.text(993,383,'Provider and full account',12,MUTED);s.text(993,412,'Manila Water / TEST-WATER-002',16,INK,600);s.line(993,435,1539,435)
 s.text(993,471,'Amount due',12,MUTED);s.text(993,500,PESO+'283.97',21,INK,600);s.text(993,547,'Due date',13,INK,600)
 s.rect(991,565,548,62,'white',9,LINE);s.text(1009,602,'October 30, 2026',18,BLUE,600)
 s.text(993,666,'Reason and source evidence',13,INK,600);s.rect(991,684,548,110,'white',9,LINE);s.text(1009,719,'The original bill shows October 30.',15,INK);s.text(1009,747,'The extracted due date was unreadable.',15,INK)
 if manager_view:
  s.text(993,835,'Prepared by Lea Santos / Today, 12:42 PM',13,MUTED);s.button(991,870,264,'Authorize correction');s.button(1273,870,266,'Reject with reason',False);s.text(993,958,'Authorization revalidates before applying changes.',13,MUTED)
 else:
  s.text(993,835,'Live billing stays unchanged until Manager authorization.',13,MUTED);s.button(991,870,360,'Submit for Manager review');s.link(1387,899,'Cancel');s.text(993,958,'Staff prepares corrections. Manager makes the decision.',13,MUTED)
 s.save('09-manager-review.svg' if manager_view else '08-source-review.svg')

if __name__ == '__main__':
 for draw in [login,manager,staff,tenant,tenant_mobile,admin,billing,correction]:draw()
 correction(True)
 print('Created 9 SVG concepts. Portal source and data unchanged.')

