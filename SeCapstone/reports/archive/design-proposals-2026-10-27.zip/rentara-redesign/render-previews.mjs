import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readdir, writeFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
const require = createRequire(new URL('../../../rentara-portal/package.json', import.meta.url));
const { chromium } = require('@playwright/test');
const browser = await chromium.launch({headless:true,...(process.platform==='win32'?{executablePath:process.env.BROWSER_EXECUTABLE||'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe'}:{})});
const audits=[];
try {
  const page=await browser.newPage({deviceScaleFactor:1,reducedMotion:'reduce'});
  await page.route(/^https?:/,route=>route.abort());
  for(const name of (await readdir(new URL('.',import.meta.url))).filter(n=>/^\d\d-.*\.svg$/.test(n)).sort()) {
    await page.goto(new URL(name,import.meta.url).href);
    await page.evaluate(()=>document.fonts.ready);
    const audit=await page.evaluate(()=>{
      const svg=document.documentElement,bounds=svg.viewBox.baseVal;
      return {width:bounds.width,height:bounds.height,parserErrors:document.querySelectorAll('parsererror').length,
        outside:[...document.querySelectorAll('text')].filter(el=>{const b=el.getBBox();return b.x<0||b.y<0||b.x+b.width>bounds.width+1||b.y+b.height>bounds.height+1;}).map(el=>el.textContent)};
    });
    assert.equal(audit.parserErrors,0,name);assert.deepEqual(audit.outside,[],name);
    await page.setViewportSize({width:audit.width,height:audit.height});
    await page.screenshot({path:fileURLToPath(new URL(name.replace('.svg','.png'),import.meta.url)),animations:'disabled'});
    audits.push({file:name,...audit});
  }
  await writeFile(new URL('render-audit.json',import.meta.url),JSON.stringify({externalRequests:'blocked',screens:audits},null,2)+'\n');
  console.log(`Rendered and checked ${audits.length} screens.`);
} finally {await browser.close();}
