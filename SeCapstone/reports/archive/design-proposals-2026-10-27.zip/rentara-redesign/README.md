# Rentara whole-system visual direction

Created 23 October 2026. **Approval concepts only; not applied to the running portal.** Open [the gallery](index.html) to review all nine SVG/PNG pairs. Existing current-portal screenshots remain in [mockups](../../mockups/README.md).

The earlier design relied on repeated bordered cards, small labels and uniformly weighted sections. This proposal gives Rentara a property-specific identity with architectural line artwork, large Georgia headings, readable sans-serif controls, open task lists and fewer enclosing boxes. The existing option 02 logo remains.

| Token | Proposed value |
| --- | --- |
| Sidebar/mobile header | Ink blue `#173d59` |
| Page | Mist `#f3f6fa` |
| Pale surface/topbar | Blue gray `#e9f0f7` |
| Text | `#18344b` |
| Secondary text | `#5d7387` |
| Action | `#315ed1` |
| Heading/body fonts | Georgia / system sans-serif; no font download |

## Screen coverage

The gallery covers login, Manager dashboard, Staff daily operations, desktop and mobile Tenant home, Admin accounts, billing records, Staff source correction and Manager proposal review. It establishes a direction for the rest of the existing pages; it does not claim every form, report, dialog or responsive state has been designed or implemented.

Manager starts with decisions; Staff starts with the work queue. Tenant starts with rent, followed immediately by personal utilities. Admin starts with accounts/workspaces and does not impersonate users. Source review keeps evidence beside the correction rather than hiding it behind navigation.

## Preserve during implementation

- Keep the current Node.js, SQLite and vanilla frontend, routes and role boundaries. Reuse existing components and functions.
- Staff prepares corrections; Manager alone authorizes financial changes and confirms rent. Existing atomic revalidation remains authoritative.
- Utility marks remain personal and provider settlement remains unverified. No utility receipts or utility notification email.
- Calendar icons distinguish actual rent/electricity/water dates. Future rent estimates stay labelled; do not predict utilities.
- Keep the existing desktop hover sidebar behavior, keyboard access, scrollable navigation and logout above the sidebar user. The expanded sidebar in these images is for reviewing labels.
- Desktop topbar stays pale blue gray. Mobile/tablet use the blue header and light blue bottom navigation. No duplicate desktop user dropdown or desktop hamburger.
- Retain existing login and account recovery behavior; the help text is guidance, not a new reset-password service.

The artwork is decorative, not a floorplan, occupancy map or new database requirement. All names, amounts and activity here are fictional layout examples, not acceptance results or actual user records. Static buttons do not perform actions.

## Motion and accessibility for the implementation

Use restrained color/opacity transitions for actions, preserve the user's slower sidebar preference, and avoid moving the page when a control is clicked. No animated financial amounts, continuously moving backgrounds or scroll hijacking. Respect reduced motion. Keep focus visible, label icons, use semantic controls, and preserve readable text and usable touch targets. Verify contrast and every responsive state in the real frontend; screenshots cannot establish accessibility compliance.

Include loading, empty, validation, failure and long-content states when applying the design. Do not hide mandatory review reasons or role distinctions to make the screen look simpler.

## Rebuild and validation

From the repository root:

```powershell
python SeCapstone/reports/design-concepts/rentara-redesign/build-concepts.py
node SeCapstone/reports/design-concepts/rentara-redesign/render-previews.mjs
```

The renderer uses the portal's installed Playwright and local Edge on Windows. External HTTP requests are blocked. It checks SVG parsing and text bounds and exports nine PNGs; results are in `render-audit.json`. This is visual-export verification, not application functionality testing. No live data, Gmail configuration, source code or current screenshot set is changed.
